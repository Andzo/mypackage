# Mypackage

Mypackage is a python library that is created for the purpose of learning how to create a python package.

## Building this package locally
`python setup.py sdist`

## Installing this package from GitHub
`pip install git+https://github.com/Andzo/my_package.git`

## Updating this package from GitHub
`pip install -- upgrade git+https://github.com/Andzo/my_package.git`
